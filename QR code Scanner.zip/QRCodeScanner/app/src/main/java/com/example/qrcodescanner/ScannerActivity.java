package com.example.qrcodescanner;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageProxy;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import com.google.android.material.button.MaterialButton;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.mlkit.vision.barcode.Barcode;
import com.google.mlkit.vision.barcode.BarcodeScanning;
import com.google.mlkit.vision.common.InputImage;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ScannerActivity extends AppCompatActivity {

    private PreviewView previewView;
    private ExecutorService cameraExecutor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scanner);

        previewView = findViewById(R.id.preview_view);
        MaterialButton btnBack = findViewById(R.id.btn_back);

        // Back button click listener
        btnBack.setOnClickListener(view -> finish());

        // Set up the camera executor
        cameraExecutor = Executors.newSingleThreadExecutor();
        startCamera();
    }

    private void startCamera() {
        // Create a ListenableFuture for CameraProvider
        ListenableFuture<ProcessCameraProvider> cameraProviderFuture = ProcessCameraProvider.getInstance(this);

        // Set listener to run when CameraProvider is ready
        cameraProviderFuture.addListener(() -> {
            try {
                // Bind camera to lifecycle
                ProcessCameraProvider cameraProvider = cameraProviderFuture.get();

                // Select the back camera
                CameraSelector cameraSelector = new CameraSelector.Builder()
                        .requireLensFacing(CameraSelector.LENS_FACING_BACK)
                        .build();

                // Create an ImageAnalysis use case
                ImageAnalysis imageAnalysis = new ImageAnalysis.Builder().build();

                // Set up an analyzer to process the camera frames
                imageAnalysis.setAnalyzer(cameraExecutor, this::analyzeImage);

                // Bind the use cases to the camera lifecycle
                Camera camera = cameraProvider.bindToLifecycle(this, cameraSelector, imageAnalysis);

            } catch (Exception e) {
                // Handle errors when starting the camera
                Toast.makeText(this, "Error starting camera: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }, getMainExecutor());
    }

    private void analyzeImage(@NonNull ImageProxy imageProxy) {
        try {
            // Convert the image to InputImage for ML Kit processing
            InputImage inputImage = InputImage.fromMediaImage(imageProxy.getImage(), imageProxy.getImageInfo().getRotationDegrees());

            // Use ML Kit to scan the QR code
            BarcodeScanning.getClient().process(inputImage)
                    .addOnSuccessListener(barcodes -> {
                        // Iterate through the detected barcodes
                        for (Barcode barcode : barcodes) {
                            // Return the scanned data
                            Intent resultIntent = new Intent();
                            resultIntent.putExtra("SCANNED_DATA", barcode.getDisplayValue());
                            setResult(RESULT_OK, resultIntent);
                            finish();
                        }
                    })
                    .addOnFailureListener(e -> {
                        // Handle scanning failure
                        Toast.makeText(this, "Failed to scan: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    })
                    .addOnCompleteListener(task -> imageProxy.close());
        } catch (Exception e) {
            // Handle errors while analyzing image
            imageProxy.close();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Shut down the camera executor when activity is destroyed
        cameraExecutor.shutdown();
    }
}