package com.example.qrcodescanner;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final int SCANNER_REQUEST_CODE = 200; // Request code for result from ScannerActivity

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Set up a button to launch the ScannerActivity
        Button btnOpenScanner = findViewById(R.id.btn_open_scanner);
        btnOpenScanner.setOnClickListener(view -> openScanner());
    }

    private void openScanner() {
        // Start the ScannerActivity for result
        Intent scannerIntent = new Intent(MainActivity.this, ScannerActivity.class);
        startActivityForResult(scannerIntent, SCANNER_REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == SCANNER_REQUEST_CODE && resultCode == RESULT_OK) {
            if (data != null) {
                String scannedData = data.getStringExtra("SCANNED_DATA");
                Toast.makeText(this, "Scanned data: " + scannedData, Toast.LENGTH_LONG).show();
            }
        }
    }
}